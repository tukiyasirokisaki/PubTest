package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Student;
import com.example.demo.mapper.StudentMapper;
import com.example.demo.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
    private StudentMapper studentmapper;
	@Override
	public List<Student> selectall() {
		// TODO Auto-generated method stub
		return studentmapper.selectall();
	}
	@Override
	public void addStudent(Student student) {
		studentmapper.addStudent(student);
	}
	@Override
	public void updateStudent(Student student) {
		studentmapper.updateStudent(student);
	}
	@Override
	public Student queryById(Integer id) {
		return studentmapper.queryById(id);
	}
	@Override
	public void deleteStudent(Integer id) {
		studentmapper.deleteStudent(id);
	}
}
