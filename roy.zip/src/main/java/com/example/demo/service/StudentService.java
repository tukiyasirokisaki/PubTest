package com.example.demo.service;

import java.util.List;
import com.example.demo.domain.Student;
public interface StudentService {
	List<Student> selectall();
	void addStudent(Student student);
	void updateStudent(Student student);
	Student queryById(Integer id);
	void deleteStudent(Integer id);
}
