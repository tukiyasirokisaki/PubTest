package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.demo.domain.Student;
import com.example.demo.mapper.StudentMapper;

@Controller
public class TestController {
	@Autowired
	private StudentMapper studentMapper;
@RequestMapping(value="/index1")
public String index(Model model) {
	List<Student> list = studentMapper.selectall();
    model.addAttribute("student", list);
    return "index1";
}
@RequestMapping("/add")
public String page(){
    return "addStudent";
}
@RequestMapping("/save")
public String addStudent(Student student){
    studentMapper.addStudent(student);
    return "redirect:index1";
}
@RequestMapping("/student/updateinfo")
public String page1(Model model,Integer id){
    model.addAttribute("student", studentMapper.queryById(id));
    return "updateStudent";
}
@RequestMapping("/update")
public String updateStudent(Student student){
   studentMapper.updateStudent(student);
    return "redirect:index1";
}
@RequestMapping("/deleteinfo")
public String deleteStudent(Integer id){
	studentMapper.deleteStudent(id);
    return "redirect:index1";
}
}
